# Change Log

## [1.0.1] 2021-02-10
### Improvements

- Bump UI: [Jinja Template Argon](https://github.com/app-generator/jinja-argon-dashboard) v1.0.1
- Bump Codebase: [Django Dashboard](https://github.com/app-generator/boilerplate-code-django-dashboard) v1.0.4 

## [1.0.0] 2020-07-30
### Initial Release
