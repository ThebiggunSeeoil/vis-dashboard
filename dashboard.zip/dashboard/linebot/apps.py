from django.apps import AppConfig


class LinebotConfig(AppConfig):
    name = 'linebot'
